package com.example.empms.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.empms.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
	Optional<Role> findByName(String name);

}
