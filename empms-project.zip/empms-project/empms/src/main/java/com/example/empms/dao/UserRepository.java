package com.example.empms.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.empms.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
	Optional<User> findByUsername(String username);

}
